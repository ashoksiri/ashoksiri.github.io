export { ProgressComponent } from './progress.component';
