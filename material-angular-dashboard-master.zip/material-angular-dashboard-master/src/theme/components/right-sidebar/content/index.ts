export { RightSidebarContentComponent } from './content.component';
