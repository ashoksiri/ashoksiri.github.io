export { RightSidebarComponent } from './sidebar.component';
