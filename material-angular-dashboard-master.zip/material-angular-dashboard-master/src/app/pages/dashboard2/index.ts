export { Dashboard2Component } from './dashboard2.component';
export { Dashboard2Module } from './dashboard2.module';
