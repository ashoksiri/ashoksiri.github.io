export { MapComponent } from './map.component';
