export { TogglesComponent } from './toggles.component';
