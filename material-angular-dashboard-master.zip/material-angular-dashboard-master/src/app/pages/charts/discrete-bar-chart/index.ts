export { DiscreteBarChartComponent } from './discrete-bar-chart.component';
export { DiscreteBarChartService } from './discrete-bar-chart.service';
