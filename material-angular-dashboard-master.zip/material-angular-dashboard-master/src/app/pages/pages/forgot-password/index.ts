export { ForgotPasswordComponent } from './forgot-password.component';
