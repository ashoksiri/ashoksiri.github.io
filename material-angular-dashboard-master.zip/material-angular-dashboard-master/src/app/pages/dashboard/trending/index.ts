export { TrendingComponent } from './trending.component';
