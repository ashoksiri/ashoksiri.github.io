export { CotoneasterCardComponent } from './cotoneaster-card.component';
