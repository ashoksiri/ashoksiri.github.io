export { RobotCardComponent } from './robot-card.component';
