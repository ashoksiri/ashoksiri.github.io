export { TablesComponent } from './tables.component';
export { TablesService } from './tables.service';
