export { ColorsComponent } from './colors.component';
