export { TypographyComponent } from './typography.component';
